//
//  KNN.h
//  MyClassifier
//
//  Created by Grant Janavs on 4/25/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#ifndef KNN_h
#define KNN_h

#include <iostream>
#include <string>
#include <cmath>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;

/*
 implemented for any k value and should use euclidian distance as distance measure.  If tie between the two classes, choose class yes
 */

class DistanceResults{
private:
	int label;
	double distanceVal;
	double distance(vector<double>& a, vector<double>& b){
		double sum = 0;
		double c = 0.0;
		for(int i =0; i < min(a.size(),b.size()); i++)
		{
			//Kahan algo to reduce floating point round off errors
			// c is running compensation value, keeps subtracted
			double y = ((a[i]-b[i])*(a[i]-b[i]))-c;
			double t = sum + y;
			c = (t-sum)-y;
			sum = t;
		}
		return sqrt(sum);
	}
public:
	DistanceResults(vector<double>& a,vector<double>& testCase){
		
		distanceVal = distance(a, testCase);
		//cout << "distance val " << distanceVal << endl;
		if(a.back() > 0.5)
		{
			label = 1;
		}
		else
		{
			label = 0;
		}
	}
	int getLabel(){
		return label;
	}
	
	double getVal(){
		return distanceVal;
	}
};

bool compare(DistanceResults a, DistanceResults b){
	return a.getVal() >= b.getVal();
}

//can also make  return int
string classify(vector<vector<double> >& TrainingData, vector<double>& TestCase, int k)
{
	vector<DistanceResults> distances;
	
	for(int i = 0; i < TrainingData.size(); i++)
	{
		distances.push_back(DistanceResults(TrainingData.at(i), TestCase));
	}
	make_heap(distances.begin(), distances.end(), compare);
	double counter = 0.0;
	for(int j = 0; j < k; j++)
	{
		counter += distances.front().getLabel();
		pop_heap(distances.begin(), distances.end()-j, compare);
	}
	if(counter/k >= .5)
	{
		return "yes";
	}
	else
	{
		return "no";
	}
}

//take in all training ex, testing
vector<string>* KNN(vector<vector<double> >& TrainingData, vector<vector<double> >& TestingData, int k)
{
	vector<string>* predictLabels = new vector<string>();
	for(int i = 0; i < TestingData.size(); i++)
	{
		
		string s =  classify(TrainingData, TestingData[i], k);
		predictLabels->push_back(s);
	}
	return predictLabels;
}

vector<string>* oneNN(vector<vector<double> >& TrainingData, vector<vector<double> >& TestingData){
	return KNN(TrainingData, TestingData, 1);
}

vector<string>* fiveNN(vector<vector<double> >& TrainingData, vector<vector<double> >& TestingData){
	return KNN(TrainingData, TestingData, 5);
}

#endif /* KNN_h */
