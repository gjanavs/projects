//
//  NB.h
//  MyClassifier
//
//  Created by Grant Janavs on 4/25/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#ifndef NB_h
#define NB_h


#include <iostream>
#include <string>
#include <cmath>
#include <cstring>
#include <algorithm>
#define _USE_MATH_DEFINES
using namespace std;

/*
 The Naïve Bayes should be implemented for numeric attributes, using a probability density function. Assume a normal distribution, i.e. use the probability density function for a normal distribution. As before, if there is ever a tie between the two classes, choose class yes.
 */

void computeMeans(vector<vector<double> >& TrainingData,vector<double>* means, int label, int attribute){
	double c =0.0;
	double sum = 0.0;
	int counter = 0;
	for(int i =0; i < TrainingData.size(); i++)
	{
		if(label == (int)TrainingData[i].back())
		{
			counter++;
			double y = (TrainingData[i][attribute])-c;
			double t = sum + y;
			c = (t-sum)-y;
			sum = t;
		}
	}
	means->at(attribute) = sum/counter;
	}

void computeAllmeans(vector<vector<double> >& TrainingData,vector<double>* means, int label){
	for(int i = 0; i < means->size(); i++)
	{
		computeMeans(TrainingData, means, label, i);
	}
	
}
	
double computeStdev(vector<vector<double> >& TrainingData,vector<double>* means, int label, int attribute){
		int counter = 0;
		double c =0.0;
		double sum = 0.0;
		for(int i =0; i < TrainingData.size(); i++)
		{
			if(label == (int)TrainingData[i].back())
			{
				counter++;
				double value = TrainingData[i][attribute]-means->at(attribute);
				double y = (value * value)-c;
				double t = sum + y;
				c = (t-sum)-y;
				sum = t;
			}
		}
	//how to handle if only 1 ex
	if(counter == 1)
	{
		return 0;
	}
	return sqrt(sum/(counter-1));
	}

void ComputeAllStdev(vector<vector<double> >& TrainingData,vector<double>* means, int label, vector<double>* stdev){
	for(int i =0; i < means->size(); i++)
	{
		stdev->at(i) = computeStdev(TrainingData, means, label, i);
	}
	
}
	 // x and mean can be close to each other
		//could rewrite with division firsst
//possible numerical issues
double probDensityFunc(double mean, double stdev, double x){
	double v = (1/(stdev * sqrt(2 * M_PI)))*exp(-((x-mean)*(x-mean))/(2*(stdev*stdev)));
	//cout << "funct " << v << endl;
	return v;
}

static vector<double> *meansYes;
static vector<double> *meansNo;
static vector<double> *stdevYes;
static vector<double> *stdevNo;

string classifyNB(double priorYes, double priorNo, vector<double>& testCase ){
	double pYes = 1;
	double pNo = 1;
	
	for(int i =0; i < meansYes->size(); i++)
	{
		pYes*= probDensityFunc(meansYes->at(i), stdevYes->at(i), testCase[i]);
	}
	for(int i =0; i < meansNo->size(); i++)
	{
		pNo *= probDensityFunc(meansNo->at(i), stdevNo->at(i), testCase[i]);
	}
	
	if(pYes*priorYes >= pNo*priorNo)
	{
		return "yes";
	}
	else
	{
		return "no";
	}
}

void initTables(size_t numAttr){
	if(meansYes == NULL)
	{
		meansYes = new vector<double>(numAttr,0);
	}
	if(meansNo == NULL)
	{
		meansNo = new vector<double>(numAttr,0);
	}
	if(stdevYes == NULL)
	{
		stdevYes = new vector<double>(numAttr,0);
	}
	if(stdevNo == NULL)
	{
		stdevNo = new vector<double>(numAttr,0);
	}
}

void cleanup(){
	delete meansYes;
	delete meansNo;
	delete stdevNo;
	delete stdevYes;
	
	meansNo = NULL;
	meansYes = NULL;
	stdevYes = NULL;
	stdevNo = NULL;
}

vector<string>* NB(vector<vector<double> >& TrainingData, vector<vector<double> >& TestingData){
	vector<string>* predictLabels = new vector<string>();
	if(TrainingData.size()<1)
	{
		return predictLabels;
	}
	initTables(TrainingData[0].size()-1);
	computeAllmeans(TrainingData, meansYes, 1);
	computeAllmeans(TrainingData, meansNo, 0);
	ComputeAllStdev(TrainingData, meansYes, 1, stdevYes);
	ComputeAllStdev(TrainingData, meansNo, 0, stdevNo);
	double priorYes = 0.0;
	double priorNo = 0.0;
	
	for(int i = 0 ; i < TrainingData.size(); i++){
		if(TrainingData[i].back() > 0.5)
		{
			priorYes+= 1;
		}
		else
		{
			priorNo+= 1;
		}
	}
	priorYes/= TrainingData.size();
	priorNo/= TrainingData.size();
	for(int i = 0; i < TestingData.size(); i++)
	{
		string s = classifyNB(priorYes, priorNo, TestingData[i]);
		predictLabels->push_back(s);
	}
	cleanup();
	return predictLabels;
}



/*
 probability density function:
 f(x) = (1/standard dev * sqrt(2*pi))*e^-((x-mean)^2/ 2 * stdev^2)
 

 st dev:
σ=√(1/(n-1) ∑_(i=1)^n▒〖(xi-μ)^2〗)〗
σ = sqrt(summation(xi-mean)^2/n-1)
 */

#endif /* NB_h */
