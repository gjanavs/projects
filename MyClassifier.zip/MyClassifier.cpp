//
//  MyClassifier.cpp
//  MyClassifier
//
//  Created by Grant Janavs on 4/25/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

/*
3 input:
	1. path to training file
 	2. path to testing file
 	3. name of algo, (NB or KNN) where k is replaced with a #
 */

#include "KNN.h"
#include "NB.h"
#include "stratified_cross_validation.h"
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <sstream>

using namespace std;

//currently can't read from the files, gets 0 with inte, reads it if string tho,
//but function calling works

//in case extra space after yes no
string trim(string v){
	string result = "";
	int i = 0;
	while(i < v.length() && isspace(v[i]))
	{
		i++;
	}
	while(i < v.length() && !isspace(v[i]))
	{
		result += v[i];
		i++;
	}
	return result;
}

int main(int argc, char* argv[]) {
	if(argc < 3){
	cout << "file or algorithm required " << endl;
		return 0;
	}
	else
	{
		ifstream fin(argv[1]);
		if(!fin)
		{
		  cout << "Cannot open training data file." << endl;
		  return 0;
		}
		string t;
		vector<vector<double> > TrainingData;
		string value;
		//get for each row
		while (getline(fin, t))
		{
			istringstream iss(t);
			TrainingData.push_back(vector<double>());
			//get up to each comma
			while (getline(iss,value, ','))
			{
				if(trim(value) == "yes")
				{
					TrainingData.back().push_back(1);
				}
				else if(trim(value) == "no")
				{
					TrainingData.back().push_back(0);
				}
				else
				{
					TrainingData.back().push_back(atof(value.c_str()));
				}
			}
		}
		
		
		ifstream fin2(argv[2]);
		if(!fin2)
		{
		  cout << "Cannot open testing data file." << endl;
		  return 0;
		}
		vector<vector<double> > TestingData;
		//get for each row
		while (getline(fin2, t))
		{
			istringstream iss(t);
			TestingData.push_back(vector<double>());
			//get up to each comma
			while (getline(iss,value, ','))
			{
				TestingData.back().push_back(atof(value.c_str()));
			}
		}
		
		
		if(strcmp(argv[3],"NB")==0)
		{
			vector<string>* result = NB(TrainingData, TestingData);
			for (int i =0; i < result->size(); i++)
			{
				cout << result->at(i) << endl;
			}
		}
		else 
		{
			int k = stoi(argv[3]);
			string NN = to_string(k) + "NN";
			char const *knn = NN.c_str();
			
			if(strcmp(argv[3], knn)==0)
			{
				vector<string>* result = KNN(TrainingData, TestingData, k);
				for (int i =0; i < result->size(); i++)
				{
					cout << result->at(i) << endl;
				}
			}
		}
		
		
		
		//could fout to file isntead
		//can comment out instead
		vector<Fold>* folds = makeFolds(TrainingData);
		output(*folds);
		
		//cout << "avg accuracy 1nn: " << avgAccuracy(*folds, oneNN) << endl;
		//cout << "avg accuracy 5nn: " << avgAccuracy(*folds, fiveNN) << endl;
		//cout << "avg accuracy NB: " << avgAccuracy(*folds, NB) << endl;
		
		
		fin.close();
		fin2.close();
	}
}



