//
//  stratified_cross_validation.h
//  MyClassifier
//
//  Created by Grant Janavs on 5/7/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#ifndef stratified_cross_validation_h
#define stratified_cross_validation_h

#include <vector>
#include <fstream>
#include <iostream>

/*
 //ask if to distribute the yes and no's
 
 10-FOLD_STRATIFIED_CROSS_VALIDATION
 
Implementation
In order to evaluate the performance of the classifiers, you will have to implement 10-fold stratified cross-validation as an extension to your classifier code. Your program should be able to show the algorithm’s average accuracy over the 10 folds. This information will be required to complete the report; you need to know the average accuracy of your NB and kNN algorithms (for various values of k).
*/

typedef vector<vector<double>* > Fold;

vector<Fold>* makeFolds(vector<vector<double> >& TrainingData){
	int nfolds = 10;
	int numYes = 0;
	int numNo = 0;
	vector<vector<double>*> yesTraining;
	vector<vector<double>*> noTraining;
	for(int i = 0; i < TrainingData.size(); i++)
	{
		if(TrainingData[i].back() > 0.5)
		{
			yesTraining.push_back(&TrainingData[i]);
		}
		else
		{
			noTraining.push_back(&TrainingData[i]);
		}
	}
	numYes = (int)yesTraining.size()/nfolds;
	numNo = (int)noTraining.size()/nfolds;
	
	vector<Fold>* folds = new vector<Fold>();
	Fold::iterator yesIt = yesTraining.begin();
	Fold::iterator noIt = noTraining.begin();
	
	for(int i = 0; i < nfolds ; i++)
	{
		folds->push_back(vector<vector<double>*>(yesIt,yesIt + numYes));
		for(int j = 0; j < numNo; j++, noIt++)
		{
			folds->back().push_back(*noIt);
		}
		yesIt = yesIt + numYes;
	}
	for(int j = 0; yesIt!=yesTraining.end(); j++, yesIt++)
	{
		folds->at(j).push_back(*yesIt);
		
	}
	for(int k = nfolds-1; noIt!=noTraining.end(); k--, noIt++)
	{
		folds->at(k).push_back(*noIt);
	}
	return folds;
}

double evaluate(vector<Fold>& folds, int testFold, vector<string>*(*classifier)(vector<vector<double> >&, vector<vector<double> >&))
{
	vector<vector<double> > testingData;
	vector<vector<double> > trainingData;
	for(int i = 0; i < folds.size(); i++)
	{
		if(i == testFold)
		{
			for(int j = 0; j < folds[i].size(); j++)
			{
				testingData.push_back(*(folds[i][j]));
				//this is to remove the label at the end
				testingData.back().pop_back();
			}
		}
		else
		{
			for(int j = 0; j < folds[i].size(); j++)
			{
				trainingData.push_back(*(folds[i][j]));
			}
		}
			
	}
	vector<string>* results = classifier(trainingData, testingData);
	double counter =0.0;
	for(int i = 0; i < results->size() ; i++)
	{
		if(results->at(i) == "yes" && folds[testFold][i]->back() >= 0.5)
		{
			counter++;
		}
		else if(results->at(i) == "no" && folds[testFold][i]->back() < 0.5)
		{
			counter++;
		}
	}
	return counter/results->size();
}

double avgAccuracy(vector<Fold>& folds, vector<string>*(*classifier)(vector<vector<double> >&, vector<vector<double> >&)){
	double sum = 0.0;
	for(int i = 0; i < folds.size() ; i++ )
	{
		sum+= evaluate(folds, i, classifier);
	}
	return sum/folds.size();
}


void output(vector<Fold> folds){
	ofstream fout("pima-folds.csv");
	for(int i = 0; i < folds.size(); i++ )
	{
		vector<vector<double>*>& fold = folds[i];
		fout << "fold" << i+1 << endl;
		for(int j = 0; j < fold.size(); j++)
		{
			for(int k = 0; k < fold[j]->size(); k++)
			{
				
				if(k < fold[j]->size()-1)
				{
					fout << fold[j]->at(k);
					fout << ",";
				}
				else if(fold[j]->at(k) < 0.5)
				{
					fout << "no";
				}
				else
				{
					fout << "yes";
				}
			}
			fout << endl;
		}
			fout << endl;
	}
}


#endif /* stratified_cross_validation_h */
