//
//  Greedy.h
//  ThreeDIgits
//
//  Created by Grant Janavs on 3/21/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#ifndef Greedy_h
#define Greedy_h

#include "Node.h"
#include <stdio.h>
#include <string.h>

int expandedNodes[1000];
int k = 0;

int ManhattanHeuristic(Node* thisNode, int goal);

void Greedy(int start, int goal, vector<int> forbidden){
	
		int c = 1000;
		bool visited[10000];
		memset(visited, 0, 10000);
		Node* thisNode = new Node(start);
		for(int i = 0;i < forbidden.size(); i++ )
		{
			visited[getVisitedKey(forbidden[i],1)]= true;
			visited[getVisitedKey(forbidden[i],2)]= true;
			visited[getVisitedKey(forbidden[i],3)]= true;
		}
		int hueristic[7];
		while(true)
		{
			expandedNodes[k++] = thisNode->key;
			visited[getVisitedKey(thisNode->key,thisNode->lastDigit)] = true;
			if(thisNode->key == goal  || k >= 1000)
			{
				break;  //done
			}
			vector<Node*> neighbors = getValidNeighbors(thisNode, visited);
			for(int j = 0 ; j < neighbors.size(); j++)
			{
				hueristic[j] = ManhattanHeuristic(neighbors[j], goal);
			}
			thisNode = neighbors[0];
			int min = hueristic[0];
			for(int j = 1 ; j < neighbors.size(); j++)
			{
				if(hueristic[j] <= min)
				{
					thisNode = neighbors[j];
					min = hueristic[j];
				}
			}
		}
		printPath(k, thisNode, expandedNodes, goal);
}

//do i need visited?
//between current number and goal number
int ManhattanHeuristic(Node* thisNode, int goal){
	int currentKey = thisNode->key;
	int firstDig = abs(currentKey/100 - goal/100);
	int secDig = abs(currentKey/10%10 - goal/10%10);
	int thirdDig = abs(currentKey%10 - goal%10);
	int hueristic = firstDig + secDig + thirdDig;
	return hueristic;
}


#endif
