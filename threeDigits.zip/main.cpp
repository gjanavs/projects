//
//  main.c
//  ThreeDIgits
//
//  Created by Grant Janavs on 3/21/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#include <fstream>
#include <string>
#include <stdio.h>
using namespace std;

#include"Hill_Climbing.h"
#include "Astar.h"
#include "Greedy.h"
#include "DFS.h"
#include "BFS.h"
#include "IDS.h"

int main(int argc,char* argv[]) {
	
 	ifstream fin(argv[2]);
 	
	if(!fin) {
	  cout << "Cannot open input file.\n";
	  return 0;
	}
	int start;
	int goal;
	
	fin >> start;
	fin >> goal;
	int j = 0;
	vector<int> forbidden;
	char c;
	while(fin >> j)
 	{
		forbidden.push_back(j);
		if(fin)
		{
			fin >> c;
		}
 	}
	
 	//DFS
	if(strcmp(argv[1],"D") == 0)
 	{
		DFS(start, goal, forbidden);
	}
	
	//BFS
	if(strcmp(argv[1],"B") == 0)
	{
		BFS(start, goal, forbidden);
	}
	
	//IDS
	if(strcmp(argv[1],"I") == 0)
	{
		IDS(start, goal, forbidden);
	}
	
	//Greedy
	if(strcmp(argv[1],"G") == 0)
	{
		Greedy(start, goal, forbidden);
	}
	
	//Hill-Climbing
	   if(strcmp(argv[1],"H")== 0)
	   {
		   HC(start, goal, forbidden);
	   }
	//A*
	if(strcmp(argv[1],"A")== 0)
	{
		Astar(start, goal, forbidden);
	}
	
	return 0;
}

