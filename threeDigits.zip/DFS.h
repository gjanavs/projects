//
//  DFS.h
//  ThreeDigits
//
//  Created by Grant  on 3/21/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#ifndef DFS_h
#define DFS_h

/*Set a limit of 1000 expanded nodes maximum, and when it is reached, stop the search and print a message that the limit has been reached
 */

#include "Node.h"
#include <stdio.h>
#include <stack>
#include <string.h>
using namespace std;

void DFS(int start, int goal, vector<int> forbidden){
	
	int c = 1000;
	stack<Node*> s;
	int nodesExpanded[c];
	bool visited[10000];
	memset(visited, 0, 10000);
	int index = 0;  //first free open spot in nodes expanded
	
	Node* thisNode = new Node(start);
	s.push(thisNode); 
	
	for(int i = 0;i < forbidden.size(); i++ )
	{
		visited[getVisitedKey(forbidden[i],1)]= true;
		visited[getVisitedKey(forbidden[i],2)]= true;
		visited[getVisitedKey(forbidden[i],3)]= true;
	}
	while(!s.empty())
	{
		thisNode = s.top();
		s.pop();
		nodesExpanded[index++] = thisNode->key;
		visited[getVisitedKey(thisNode->key,thisNode->lastDigit)] = true;
		if(thisNode->key == goal || index >= 1000)
		{
			break;  //done
		}
		//process node
		vector<Node*> neighbors = getValidNeighbors(thisNode, visited);
		for(int j = (int)neighbors.size()-1; j >= 0; j--)
		{
			s.push(neighbors[j]);
		}
	}
	printPath(index, thisNode, nodesExpanded, goal);
}
			
#endif
