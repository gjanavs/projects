//
//  BFS.h
//  ThreeDIgits
//
//  Created by Grant Janavs on 3/21/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#ifndef BFS_H
#define BFS_H

#include "Node.h"
#include <stdio.h>
#include <queue>
#include <string.h>
using namespace std;

void BFS(int start, int goal, vector<int> forbidden){
	int c = 1000;
	queue<Node*> q;
	int nodesExpanded[c];
	bool visited[10000];
	memset(visited, 0, 10000);
	int index = 0;  //first free open spot in nodes expanded
	
	Node* thisNode = new Node(start);
	q.push(thisNode); 
	
	for(int i = 0;i < forbidden.size(); i++ )
	{
		visited[getVisitedKey(forbidden[i],1)]= true;
		visited[getVisitedKey(forbidden[i],2)]= true;
		visited[getVisitedKey(forbidden[i],3)]= true;
	}
	while(!q.empty())
	{
		thisNode = q.front();
		q.pop();
		nodesExpanded[index++] = thisNode->key;
		visited[getVisitedKey(thisNode->key,thisNode->lastDigit)] = true;
		if(thisNode->key == goal || index >= 1000)
		{
			break;  //done
		}
		//process node
		vector<Node*> neighbors = getValidNeighbors(thisNode, visited);
		for(int j = 0 ; j < neighbors.size(); j++)
		{
			q.push(neighbors[j]);
		}
	}
	printPath(index, thisNode, nodesExpanded, goal);
}

#endif
