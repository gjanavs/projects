
//
//  IDS.h
//  ThreeDIgits
//
//  Created by Grant Janavs on 3/21/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//
#ifndef IDS_H
#define IDS_H

#include "Node.h"
#include <stdio.h>
#include <vector>

int nodesExpanded[1000];
int nodeIndex = 0;

Node* DFS2(int start, int goal, vector<int> forbidden, int maxDepth);
	
void IDS(int start, int goal, vector<int> forbidden){
	Node* thisNode;
	int limit = 1000;
	for(int i=0; i < limit; i++)
	{
		thisNode = DFS2(start, goal, forbidden, i);
		if( thisNode->key == goal)
		{
			break;
		}
	}
	printPath(nodeIndex, thisNode, nodesExpanded, goal);
}

Node* DFS2(int start, int goal, vector<int> forbidden, int maxDepth){
	
	int c = 1000;
	stack<Node*> s;
	bool visited[10000];
	memset(visited, 0, 10000);
	Node* thisNode = new Node(start);
	thisNode->depth = 0;
	s.push(thisNode);
	
	for(int i = 0;i < forbidden.size(); i++ )
	{
		visited[getVisitedKey(forbidden[i],1)]= true;
		visited[getVisitedKey(forbidden[i],2)]= true;
		visited[getVisitedKey(forbidden[i],3)]= true;
	}
	while(!s.empty())
	{
		thisNode = s.top();
		s.pop();
		nodesExpanded[nodeIndex++] = thisNode->key;
		if(thisNode->depth == maxDepth)
		{
			if(thisNode->key == goal)
			{
				break;  //done
			}
			else
			{
				continue;
			}
		}
		visited[getVisitedKey(thisNode->key,thisNode->lastDigit)] = true;
		//process node
		vector<Node*> neighbors = getValidNeighbors(thisNode, visited);
		for(int j = (int)neighbors.size()-1; j >= 0; j--)
		{
			neighbors[j]->depth = thisNode->depth + 1;
			s.push(neighbors[j]);
		}
	}
	return thisNode;
}

#endif
