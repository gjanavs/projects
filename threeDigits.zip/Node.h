//
//  Node.h
//  ThreeDIgits
//
//  Created by Grant Janavs on 3/21/20.
//  Copyright © 2020 Grant Janavs. All rights reserved.
//

#ifndef NODE_H
#define NODE_H

#include <vector>
#include <iostream>
#include <cmath>
#include <string>
#include<sstream>
#include <unordered_set>
using namespace std;

class Node{
	
public:
	int key;
	int lastDigit;
	int depth;
	int hueristic;
	
	Node* parent;
	
	Node(int, int = 0, Node* = nullptr);
};

Node::Node(int data, int lDig, Node* P){
	key = data;
	lastDigit = lDig;
	parent = P;
	hueristic = 9999;
}

int getVisitedKey(int key, int lastDigit){
	return key*10+lastDigit;
}

std::vector<Node*> getValidNeighbors(Node* thisNode, bool visited[]){
	int currentKey = thisNode->key;
	std::vector<Node*> result;
	
	if(currentKey >= 100 && !visited[getVisitedKey(currentKey - 100,1)] && thisNode->lastDigit != 1)
	{
		result.push_back(new Node(currentKey-100, 1, thisNode));
	}
	if(currentKey < 900 && !visited[getVisitedKey(currentKey + 100,1)] && thisNode->lastDigit != 1)
	{
		result.push_back(new Node(currentKey+100, 1, thisNode));
	}
	if(currentKey%100 >= 10 && !visited[getVisitedKey(currentKey - 10,2)] && thisNode-> lastDigit != 2)
	{
		result.push_back(new Node(currentKey-10, 2, thisNode));
	}
	if(currentKey%100 < 90 && !visited[getVisitedKey(currentKey + 10,2)] && thisNode-> lastDigit != 2)
	{
		result.push_back(new Node(currentKey+ 10, 2, thisNode));
	}
	if(currentKey%10 >= 1 && !visited[getVisitedKey(currentKey - 1,3)] && thisNode-> lastDigit != 3)
	{
		result.push_back(new Node(currentKey-1, 3, thisNode));
	}
	if(currentKey%10 < 9 && !visited[getVisitedKey(currentKey + 1,3)] && thisNode-> lastDigit != 3)
	{
		result.push_back(new Node(currentKey+1, 3, thisNode));
	}
	return result;
}

void printPath(int index, Node* thisNode, int nodesExpanded[], int goal){
	if(thisNode->key != goal){
		cout << "No solution found." << endl;
	}
	else
	{
		int pathLength = 0;
		int path[1000];
		while(thisNode!= NULL)
		{
			path[pathLength++] = thisNode->key;
			thisNode = thisNode->parent;
		}
		cout << "Path: ";
		for(int j = pathLength - 1; j >= 0; j--)
		{
			cout  << path[j];
			if(j > 0)
			{
				cout << ", ";
			}
		}
		std::cout << std::endl;
	}
	cout << "nodes Expanded: ";
	for(int j = 0; j < index; j++)
	{
	cout << nodesExpanded[j];
		if(j < index-1)
		{
			cout << ", ";
		}
	}
	std::cout << std::endl;
}


#endif /* Node_h*/

